import React from "react";

const NotFound = () => {
  return (
    <div>
      <p id="not-found-txt">The page you are looking for is not yet developed.</p>
    </div>
  );
};

export default NotFound;
